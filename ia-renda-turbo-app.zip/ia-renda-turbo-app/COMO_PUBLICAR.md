# 🚀 CyberCode — Como Publicar Online

## ✅ O que está nesta pasta

- `public/index.html` → Frontend completo com sua logo
- `server.js` → Servidor que protege sua API Key
- `package.json` → Configuração do projeto

---

## 🔐 PASSO 1 — Coloque sua API Key

Abra o arquivo `server.js` e encontre esta linha:

```
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY || 'SUA_API_KEY_AQUI';
```

Substitua `SUA_API_KEY_AQUI` pela sua chave real da Anthropic.

---

## ☁️ PASSO 2 — Publicar no Render.com (GRÁTIS)

1. Acesse https://render.com e crie uma conta grátis
2. Clique em **"New +"** → **"Web Service"**
3. Conecte seu GitHub (suba esta pasta para um repositório)
4. Configure:
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
5. Em **Environment Variables**, adicione:
   - Key: `ANTHROPIC_API_KEY`
   - Value: sua chave sk-ant-...
6. Clique **Deploy** — em 2 minutos seu site está online!

---

## 💳 PASSO 3 — Conectar pagamento

No arquivo `public/index.html`, encontre a função:

```javascript
function desbloquear() {
  alert('🔗 Aqui entra seu link de checkout!...');
}
```

Substitua o `alert` por:

```javascript
window.open('SEU_LINK_KIWIFY_OU_HOTMART', '_blank');
```

---

## 📊 Seu modelo de negócio

- Cliente acessa → preenche dados → recebe prévia GRÁTIS
- Plano completo bloqueado → botão de R$27
- Custo por plano gerado: ~R$0,03
- Margem: 99%

