const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 🔐 Sua API Key fica AQUI no servidor — cliente nunca vê
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY || 'SUA_API_KEY_AQUI';

app.post('/api/gerar-plano', async (req, res) => {
  const { nome, renda, meta, tempo, habilidades, prompt_override } = req.body;

  // Ideas generator uses prompt_override directly
  if (prompt_override) {
    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{ role: 'user', content: prompt_override }]
        })
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error.message);
      const text = data.content.map(b => b.text || '').join('');
      return res.json({ result: text });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  if (!nome || !renda || !meta || !tempo || !habilidades) {
    return res.status(400).json({ error: 'Dados incompletos' });
  }

  const prompt = `Você é um especialista em geração de renda com foco em execução prática.
Crie um plano simples, direto e executável.

REGRAS:
- Nada de teoria
- Apenas ações práticas
- Priorize velocidade de ganho
- Adapte ao nível do usuário

DADOS:
Nome: ${nome}
Renda atual: ${renda}
Meta: ${meta}
Tempo disponível: ${tempo}
Habilidades: ${habilidades}

Entregue APENAS estas duas seções:

## 🎯 ESTRATÉGIA PRINCIPAL
(3 a 5 linhas diretas sobre a melhor estratégia para este perfil)

## 💡 POR QUE ISSO FUNCIONA PARA ${nome.toUpperCase()}
(2 a 3 linhas explicando por que esta estratégia é ideal para este perfil específico)

Seja direto, personalizado e convincente. Termine com uma frase que gere curiosidade sobre o plano completo.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data = await response.json();
    if (data.error) throw new Error(data.error.message);

    const text = data.content.map(b => b.text || '').join('');
    res.json({ result: text });

  } catch (err) {
    res.status(500).json({ error: err.message || 'Erro interno' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ IA Renda Turbo rodando na porta ${PORT}`));
